
import React, { useState } from 'react';
import { Page, Attendee } from '../types';
import { api } from '../api';

interface CarnivalJourneyPageProps {
  user: Attendee | null;
  onNavigate: (page: Page) => void;
  onUpdate: () => void;
}

const CARNIVAL_ZONES = [
  { id: 'Z1', name: 'Adventure Arena', icon: 'fa-mountain-sun', color: 'bg-orange-500' },
  { id: 'Z2', name: 'Tech Innovation Hub', icon: 'fa-microchip', color: 'bg-blue-600' },
  { id: 'Z3', name: 'Heritage Gallery', icon: 'fa-landmark', color: 'bg-red-600' },
  { id: 'Z4', name: 'Kids Fun Zone', icon: 'fa-child-reaching', color: 'bg-green-500' },
  { id: 'Z5', name: 'Culinary Street', icon: 'fa-utensils', color: 'bg-yellow-500' }
];

const CarnivalJourneyPage: React.FC<CarnivalJourneyPageProps> = ({ user, onNavigate, onUpdate }) => {
  const [tab, setTab] = useState<'RULES' | 'EXPLORE'>('RULES');
  const [scanning, setScanning] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  if (!user) return null;

  const handleScanSimulation = async (zoneId: string, status: 'ATTEMPTED' | 'PARTIAL' | 'COMPLETED', pts: number) => {
    setLoading(true);
    await api.updateZoneProgress(user.id, zoneId, status, pts);
    onUpdate();
    setScanning(null);
    setLoading(false);
  };

  const getZoneStatus = (id: string) => user.carnivalProgress.find(z => z.zoneId === id);

  return (
    <div className="min-h-screen bg-[#F0F2F5] pb-10 flex flex-col items-center">
      <div className="w-full max-w-[450px] bg-white shadow-2xl min-h-screen flex flex-col font-sans relative">
        <div className="bg-[#002C5F] p-6 pt-10 text-white relative">
          <div className="flex items-center justify-between mb-6">
            <button onClick={() => onNavigate(Page.USER_PROFILE)} className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center"><i className="fas fa-chevron-left"></i></button>
            <h2 className="text-lg font-black uppercase tracking-widest">Explorer Guide</h2>
            <div className="w-10"></div>
          </div>
          <div className="flex bg-white/10 p-1 rounded-2xl">
             <button onClick={() => setTab('RULES')} className={`flex-grow py-3 text-xs font-bold rounded-xl ${tab === 'RULES' ? 'bg-white text-[#002C5F]' : 'text-white'}`}>RULES & DO'S</button>
             <button onClick={() => setTab('EXPLORE')} className={`flex-grow py-3 text-xs font-bold rounded-xl ${tab === 'EXPLORE' ? 'bg-white text-[#002C5F]' : 'text-white'}`}>EXPLORE ZONES</button>
          </div>
        </div>

        <div className="flex-grow p-6 flex flex-col">
          {tab === 'RULES' ? (
            <div className="space-y-6 animate-fadeIn">
              <div className="bg-blue-50 p-6 rounded-[2rem] border border-blue-100">
                <h3 className="font-black text-[#002C5F] uppercase text-sm mb-4">Digital Passport Overview</h3>
                <p className="text-xs text-gray-500 leading-relaxed">Each zone you visit has a unique QR code. Simply scan to earn points!</p>
              </div>
              <div className="space-y-4">
                <h4 className="text-xs font-black text-[#002C5F] uppercase tracking-widest ml-2">Carnival Do's & Don'ts</h4>
                <ul className="space-y-3">
                  {["Wait for crew verification post-activity.", "Enjoy the hospitality zones responsibly.", "Duplicate scans are strictly monitored."].map((rule, idx) => (
                    <li key={idx} className="flex items-start space-x-3 text-xs text-gray-500"><i className="fas fa-check-circle text-[#00AAD2] mt-0.5"></i><span>{rule}</span></li>
                  ))}
                </ul>
              </div>
              <button onClick={() => setTab('EXPLORE')} className="w-full py-5 bg-[#00AAD2] text-white font-black rounded-2xl shadow-xl mt-auto">DISCOVER THE ZONES</button>
            </div>
          ) : (
            <div className="space-y-4 animate-fadeIn">
               {CARNIVAL_ZONES.map(zone => {
                 const progress = getZoneStatus(zone.id);
                 return (
                    <div key={zone.id} className="bg-white border border-gray-100 p-5 rounded-[2rem] shadow-sm flex items-center justify-between">
                       <div className="flex items-center space-x-4">
                          <div className={`w-12 h-12 ${zone.color} text-white rounded-2xl flex items-center justify-center text-xl shadow-lg`}><i className={`fas ${zone.icon}`}></i></div>
                          <div>
                            <h4 className="font-bold text-gray-900">{zone.name}</h4>
                            <p className="text-[9px] font-black text-gray-300 uppercase">{progress?.status === 'NONE' ? 'Not Explored' : `Status: ${progress?.status}`}</p>
                          </div>
                       </div>
                       <div className="text-right">
                          {progress?.status !== 'COMPLETED' ? (
                            <button onClick={() => setScanning(zone.id)} className="px-4 py-2 bg-[#002C5F] text-white text-[10px] font-black rounded-xl">Scan Zone</button>
                          ) : (
                            <div className="w-8 h-8 bg-green-50 text-green-500 rounded-full flex items-center justify-center shadow-inner"><i className="fas fa-check text-xs"></i></div>
                          )}
                       </div>
                    </div>
                 );
               })}
            </div>
          )}
        </div>

        {scanning && (
          <div className="absolute inset-0 bg-black/60 backdrop-blur-md z-50 flex items-center justify-center p-6 animate-fadeIn">
            <div className="bg-white w-full rounded-[3rem] p-10 text-center relative">
               {loading ? (
                 <div className="py-10 flex flex-col items-center"><div className="w-12 h-12 border-4 border-[#00AAD2] border-t-transparent rounded-full animate-spin"></div></div>
               ) : (
                 <>
                   <button onClick={() => setScanning(null)} className="absolute top-6 right-6 text-gray-300"><i className="fas fa-times text-xl"></i></button>
                   <h3 className="text-xl font-black text-[#002C5F] mb-2 uppercase tracking-tight">QR Verified!</h3>
                   <p className="text-xs text-gray-500 mb-8">Choose completion for <span className="text-[#00AAD2] font-black">{CARNIVAL_ZONES.find(z => z.id === scanning)?.name}</span>:</p>
                   <div className="space-y-3">
                      <button onClick={() => handleScanSimulation(scanning, 'COMPLETED', 10)} className="w-full py-4 bg-green-500 text-white font-bold rounded-2xl flex justify-between px-6 items-center"><span>Full Activity</span><span className="bg-white/20 px-2 py-0.5 rounded-lg text-[10px]">10 PTS</span></button>
                      <button onClick={() => handleScanSimulation(scanning, 'PARTIAL', 7.5)} className="w-full py-4 bg-blue-500 text-white font-bold rounded-2xl flex justify-between px-6 items-center"><span>Partial Progress</span><span className="bg-white/20 px-2 py-0.5 rounded-lg text-[10px]">7.5 PTS</span></button>
                      <button onClick={() => handleScanSimulation(scanning, 'ATTEMPTED', 5)} className="w-full py-4 bg-gray-400 text-white font-bold rounded-2xl flex justify-between px-6 items-center"><span>Participation</span><span className="bg-white/20 px-2 py-0.5 rounded-lg text-[10px]">5 PTS</span></button>
                   </div>
                 </>
               )}
            </div>
          </div>
        )}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-6 bg-black rounded-b-2xl"></div>
      </div>
    </div>
  );
};

export default CarnivalJourneyPage;
