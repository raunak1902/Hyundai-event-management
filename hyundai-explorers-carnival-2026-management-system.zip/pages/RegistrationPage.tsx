
import React, { useState } from 'react';
import { Page, Attendee, RegistrationStatus, AccompanyingMember } from '../types';
import { EVENT_DETAILS } from '../constants';
import { api } from '../api';

interface RegistrationPageProps {
  onSubmit: (attendee: Attendee) => void;
  onNavigate: (page: Page) => void;
}

const RegistrationPage: React.FC<RegistrationPageProps> = ({ onSubmit, onNavigate }) => {
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    vehicleModel: '',
    vehicleRegNo: '',
  });
  const [rcFile, setRcFile] = useState<string | null>(null);
  const [members, setMembers] = useState<AccompanyingMember[]>([]);

  const handleAddMember = () => {
    setMembers([...members, { name: '', age: 0 }]);
  };

  const handleMemberChange = (index: number, field: keyof AccompanyingMember, value: string | number) => {
    const newMembers = [...members];
    newMembers[index] = { ...newMembers[index], [field]: value };
    setMembers(newMembers);
  };

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.name.trim()) newErrors.name = 'Full name is required';
    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Email is invalid';
    }
    if (!formData.phone.trim()) {
      newErrors.phone = 'Phone number is required';
    } else if (!/^\d{10}$/.test(formData.phone)) {
      newErrors.phone = 'Enter a valid 10-digit number';
    }
    if (!formData.vehicleModel) newErrors.vehicleModel = 'Vehicle model is required';
    if (!formData.vehicleRegNo.trim()) newErrors.vehicleRegNo = 'Registration number is required';
    if (!rcFile) newErrors.rcFile = 'RC copy upload is required for verification';

    members.forEach((m, i) => {
      if (!m.name.trim()) newErrors[`member_name_${i}`] = 'Member name is required';
      if (m.age <= 0) newErrors[`member_age_${i}`] = 'Valid age is required';
    });

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        setErrors({ ...errors, rcFile: 'File size should be less than 2MB' });
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setRcFile(reader.result as string);
        setErrors(prev => {
          const { rcFile, ...rest } = prev;
          return rest;
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    
    setLoading(true);
    try {
      const attendee = await api.register({
        ...formData,
        members,
        rcFile: rcFile || undefined,
        paymentStatus: RegistrationStatus.PAID,
      });
      onSubmit(attendee);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const inputClass = (field: string) => `w-full px-4 py-3 rounded-xl border ${errors[field] ? 'border-red-500' : 'border-gray-200'} bg-white text-gray-900 focus:ring-2 focus:ring-blue-500 outline-none transition-all`;

  return (
    <div className="py-12 bg-gray-50 min-h-screen">
      <div className="max-w-3xl mx-auto px-4">
        <div className="bg-white rounded-3xl shadow-xl p-8 md:p-12">
          <div className="mb-10 text-center">
            <h2 className="text-3xl font-bold text-[#002C5F] mb-2">Registration</h2>
            <p className="text-gray-500">Secure your spot at the Carnival 2026</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-sm font-semibold text-gray-700">Full Name</label>
                <input 
                  className={inputClass('name')}
                  value={formData.name}
                  onChange={e => setFormData({...formData, name: e.target.value})}
                  placeholder="Enter your full name"
                />
                {errors.name && <p className="text-red-500 text-xs mt-1">{errors.name}</p>}
              </div>
              <div className="space-y-2">
                <label className="text-sm font-semibold text-gray-700">Email Address</label>
                <input 
                  type="email"
                  className={inputClass('email')}
                  value={formData.email}
                  onChange={e => setFormData({...formData, email: e.target.value})}
                  placeholder="name@example.com"
                />
                {errors.email && <p className="text-red-500 text-xs mt-1">{errors.email}</p>}
              </div>
              <div className="space-y-2">
                <label className="text-sm font-semibold text-gray-700">Mobile Number</label>
                <input 
                  type="tel"
                  className={inputClass('phone')}
                  value={formData.phone}
                  onChange={e => setFormData({...formData, phone: e.target.value})}
                  placeholder="10-digit number"
                />
                {errors.phone && <p className="text-red-500 text-xs mt-1">{errors.phone}</p>}
              </div>
              <div className="space-y-2">
                <label className="text-sm font-semibold text-gray-700">Vehicle Model</label>
                <select 
                  className={inputClass('vehicleModel')}
                  value={formData.vehicleModel}
                  onChange={e => setFormData({...formData, vehicleModel: e.target.value})}
                >
                  <option value="">Select Model</option>
                  <option>Creta</option>
                  <option>Verna</option>
                  <option>Alcazar</option>
                  <option>Tucson</option>
                  <option>Ioniq 5</option>
                  <option>Venue</option>
                  <option>Exter</option>
                </select>
                {errors.vehicleModel && <p className="text-red-500 text-xs mt-1">{errors.vehicleModel}</p>}
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-semibold text-gray-700">Vehicle Registration No. (e.g. DL 01 AB 1234)</label>
              <input 
                className={inputClass('vehicleRegNo') + " uppercase"}
                value={formData.vehicleRegNo}
                onChange={e => setFormData({...formData, vehicleRegNo: e.target.value})}
                placeholder="Registration Plate Number"
              />
              {errors.vehicleRegNo && <p className="text-red-500 text-xs mt-1">{errors.vehicleRegNo}</p>}
            </div>

            <div className="space-y-2">
              <label className="text-sm font-semibold text-gray-700">Upload Registration Certificate (RC Copy)</label>
              <div className={`relative group border-2 border-dashed rounded-2xl p-6 text-center transition-all ${errors.rcFile ? 'border-red-300 bg-red-50' : 'border-gray-200 hover:border-blue-400 bg-gray-50'}`}>
                <input 
                  type="file" 
                  accept="image/*,application/pdf"
                  onChange={handleFileChange}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                />
                <div className="flex flex-col items-center">
                  <i className={`fas ${rcFile ? 'fa-check-circle text-green-500' : 'fa-cloud-upload-alt text-gray-400'} text-3xl mb-2`}></i>
                  <p className="text-sm font-medium text-gray-600">
                    {rcFile ? 'File Uploaded Successfully' : 'Click or Drag to upload RC copy'}
                  </p>
                  <p className="text-xs text-gray-400 mt-1">PDF or Image (Max 2MB)</p>
                </div>
              </div>
              {errors.rcFile && <p className="text-red-500 text-xs mt-1">{errors.rcFile}</p>}
            </div>

            <div className="border-t pt-8">
              <div className="flex justify-between items-center mb-4">
                <h3 className="font-bold text-gray-800">Accompanying Members</h3>
                <button 
                  type="button"
                  onClick={handleAddMember}
                  className="text-sm font-bold text-blue-600 hover:text-blue-800"
                >
                  + Add Member
                </button>
              </div>
              
              {members.length === 0 && (
                <p className="text-sm text-gray-400 italic">No additional members added yet.</p>
              )}

              <div className="space-y-4">
                {members.map((member, idx) => (
                  <div key={idx} className="space-y-2">
                    <div className="flex gap-4 items-end">
                      <div className="flex-grow space-y-1">
                        <label className="text-xs font-bold text-gray-500 uppercase">Name</label>
                        <input 
                          className={`w-full px-3 py-2 rounded-lg border ${errors[`member_name_${idx}`] ? 'border-red-500' : 'border-gray-200'} bg-white text-gray-900`}
                          value={member.name}
                          onChange={e => handleMemberChange(idx, 'name', e.target.value)}
                        />
                      </div>
                      <div className="w-24 space-y-1">
                        <label className="text-xs font-bold text-gray-500 uppercase">Age</label>
                        <input 
                          type="number"
                          className={`w-full px-3 py-2 rounded-lg border ${errors[`member_age_${idx}`] ? 'border-red-500' : 'border-gray-200'} bg-white text-gray-900`}
                          value={member.age || ''}
                          onChange={e => handleMemberChange(idx, 'age', parseInt(e.target.value) || 0)}
                        />
                      </div>
                      <button 
                        type="button"
                        onClick={() => setMembers(members.filter((_, i) => i !== idx))}
                        className="p-2 text-red-500 hover:bg-red-50 rounded-lg"
                      >
                        <i className="fas fa-trash"></i>
                      </button>
                    </div>
                    {errors[`member_name_${idx}`] && <p className="text-red-500 text-[10px]">{errors[`member_name_${idx}`]}</p>}
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-blue-50 p-6 rounded-2xl flex justify-between items-center">
              <div>
                <p className="text-sm text-gray-600">Total Registration Fee</p>
                <p className="text-2xl font-bold text-[#002C5F]">₹{EVENT_DETAILS.fee}</p>
              </div>
              <button 
                type="submit"
                disabled={loading}
                className={`px-8 py-4 bg-[#00AAD2] text-white font-bold rounded-xl shadow-lg shadow-blue-200 transition-all ${loading ? 'opacity-50 cursor-not-allowed' : 'hover:scale-105 active:scale-95'}`}
              >
                {loading ? 'Processing...' : 'Proceed to Pay'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default RegistrationPage;
