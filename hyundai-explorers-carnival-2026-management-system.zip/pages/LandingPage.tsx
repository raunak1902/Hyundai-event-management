
import React, { useState } from 'react';
import { Page } from '../types';
import { EVENT_DETAILS } from '../constants';

interface LandingPageProps {
  onNavigate: (page: Page) => void;
  onGuestLogin: (code: string) => boolean;
}

const LandingPage: React.FC<LandingPageProps> = ({ onNavigate, onGuestLogin }) => {
  const [code, setCode] = useState('');
  const [error, setError] = useState(false);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const success = onGuestLogin(code);
    if (!success) {
      setError(true);
      setTimeout(() => setError(false), 3000);
    }
  };

  return (
    <div className="animate-fadeIn">
      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex items-center bg-[#E8E1D9]">
        <div className="absolute inset-0 z-0 overflow-hidden">
          <img 
            src="https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?auto=format&fit=crop&q=80&w=2070" 
            alt="Adventure Road" 
            className="w-full h-full object-cover opacity-30"
          />
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 py-20">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="max-w-xl">
              <span className="inline-block px-3 py-1 bg-[#002C5F] text-white text-xs font-bold tracking-widest rounded-full mb-4">
                EXCLUSIVELY FOR HYUNDAI OWNERS
              </span>
              <h1 className="text-6xl md:text-7xl font-bold text-[#002C5F] leading-tight mb-6">
                Explorers <br/><span className="text-[#00AAD2]">Carnival 2026</span>
              </h1>
              <p className="text-lg text-gray-700 mb-10 leading-relaxed">
                Join the largest gathering of Hyundai enthusiasts in {EVENT_DETAILS.city}. A day of thrill, community, and the spirit of exploration.
              </p>
              <div className="flex flex-wrap gap-4">
                <button 
                  onClick={() => onNavigate(Page.REGISTRATION)}
                  className="px-10 py-4 bg-[#002C5F] text-white font-bold rounded-full hover:scale-105 transition-transform shadow-xl"
                >
                  Book My Slot
                </button>
                <button 
                  onClick={() => document.getElementById('details')?.scrollIntoView({behavior: 'smooth'})}
                  className="px-10 py-4 bg-white text-[#002C5F] font-bold rounded-full border border-gray-200 hover:bg-gray-50 transition-colors"
                >
                  View Details
                </button>
              </div>
            </div>

            {/* Already Registered Sidebar */}
            <div className="bg-white/80 backdrop-blur-md p-8 md:p-10 rounded-[3rem] shadow-2xl border border-white/50 max-w-md w-full ml-auto">
              <div className="mb-6">
                <h3 className="text-xl font-black text-[#002C5F] mb-2 uppercase tracking-tight">Already Registered?</h3>
                <p className="text-sm text-gray-500">Access your live digital profile to participate in today's activities.</p>
              </div>
              <form onSubmit={handleLogin} className="space-y-4">
                <div className="relative">
                  <input 
                    type="text"
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    placeholder="Enter Registration ID"
                    className={`w-full px-6 py-4 rounded-2xl bg-white border-2 text-gray-900 font-bold tracking-widest placeholder:text-gray-300 placeholder:font-normal outline-none transition-all uppercase ${error ? 'border-red-500 animate-shake' : 'border-[#002C5F]/10 focus:border-[#00AAD2]'}`}
                  />
                  <div className="absolute right-4 top-1/2 -translate-y-1/2 text-[#00AAD2]">
                    <i className="fas fa-qrcode text-xl"></i>
                  </div>
                </div>
                {error && <p className="text-red-500 text-[10px] font-bold uppercase ml-2">ID not found. Please check your ticket.</p>}
                <button 
                  type="submit"
                  className="w-full py-4 bg-[#00AAD2] text-white font-bold rounded-2xl hover:bg-[#0091b3] transition-colors shadow-lg shadow-blue-200 flex items-center justify-center"
                >
                  Enter Command Center
                  <i className="fas fa-arrow-right ml-3"></i>
                </button>
                <p className="text-center text-[10px] text-gray-400 mt-4 italic">
                  Find your ID on the PDF ticket sent to your email (e.g., HYU-1234)
                </p>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Info Section */}
      <section id="details" className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center mb-16">
          <h2 className="text-3xl font-black text-[#002C5F] uppercase tracking-tighter mb-4">Event Experience</h2>
          <div className="w-20 h-1.5 bg-[#00AAD2] mx-auto rounded-full"></div>
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-12 text-center">
            <div className="p-8 rounded-[2.5rem] bg-gray-50 hover:shadow-xl transition-all border border-gray-100">
              <div className="w-16 h-16 bg-[#002C5F] text-white rounded-2xl flex items-center justify-center mx-auto mb-6 text-2xl shadow-lg">
                <i className="fas fa-calendar-alt"></i>
              </div>
              <h3 className="text-xl font-bold mb-2 text-[#002C5F]">When</h3>
              <p className="text-gray-600 font-medium">{EVENT_DETAILS.date}</p>
              <p className="text-gray-500 text-sm mt-1">{EVENT_DETAILS.registrationTime} onwards</p>
            </div>
            <div className="p-8 rounded-[2.5rem] bg-gray-50 hover:shadow-xl transition-all border border-gray-100">
              <div className="w-16 h-16 bg-[#00AAD2] text-white rounded-2xl flex items-center justify-center mx-auto mb-6 text-2xl shadow-lg">
                <i className="fas fa-map-marker-alt"></i>
              </div>
              <h3 className="text-xl font-bold mb-2 text-[#002C5F]">Where</h3>
              <p className="text-gray-600 font-medium">{EVENT_DETAILS.venue}</p>
              <p className="text-gray-500 text-sm mt-1">{EVENT_DETAILS.city}</p>
            </div>
            <div className="p-8 rounded-[2.5rem] bg-gray-50 hover:shadow-xl transition-all border border-gray-100">
              <div className="w-16 h-16 bg-[#002C5F] text-white rounded-2xl flex items-center justify-center mx-auto mb-6 text-2xl shadow-lg">
                <i className="fas fa-ticket-alt"></i>
              </div>
              <h3 className="text-xl font-bold mb-2 text-[#002C5F]">Entry Fee</h3>
              <p className="text-gray-600 font-medium">₹{EVENT_DETAILS.fee} per vehicle</p>
              <p className="text-gray-500 text-sm mt-1">Inclusive of snacks & goodies</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default LandingPage;
