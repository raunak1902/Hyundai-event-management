
import React, { useState } from 'react';
import { Page, Attendee } from '../types';

interface PaymentSuccessPageProps {
  user: Attendee | null;
  onNavigate: (page: Page) => void;
}

const PaymentSuccessPage: React.FC<PaymentSuccessPageProps> = ({ user, onNavigate }) => {
  const [activationCode, setActivationCode] = useState('');
  const [error, setError] = useState('');

  if (!user) return null;

  const handleActivate = () => {
    if (activationCode.toUpperCase() === user.id) {
      onNavigate(Page.USER_PROFILE);
    } else {
      setError('Please enter your unique Registration ID found on your ticket.');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4">
      <div className="max-w-md w-full bg-white rounded-[2.5rem] shadow-2xl p-10 text-center animate-scaleIn border border-gray-100">
        <div className="w-20 h-20 bg-green-50 text-green-500 rounded-full flex items-center justify-center mx-auto mb-6 text-3xl shadow-inner">
          <i className="fas fa-check"></i>
        </div>
        <h2 className="text-3xl font-black text-[#002C5F] mb-4">Registration Confirmed!</h2>
        <p className="text-gray-500 text-sm mb-8 leading-relaxed">
          Welcome aboard, <span className="font-bold text-gray-800">{user.name}</span>! Your slot for the Lucknow Carnival 2026 is secured.
        </p>
        
        <div className="bg-blue-50/50 rounded-3xl p-6 mb-8 text-left border border-blue-100/50">
          <p className="text-[10px] font-black text-blue-400 uppercase tracking-widest mb-2">Activation Step</p>
          <p className="text-sm text-blue-900 mb-4">
            Once you reach the venue and receive your <strong>RFID Wristband</strong>, scan it to access your Digital Profile. Or enter your ID below to preview your command center:
          </p>
          <div className="flex gap-2">
            <input 
              className="flex-grow bg-white border border-blue-200 rounded-xl px-4 py-3 text-sm font-bold uppercase tracking-widest outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Enter ID (e.g. HYU-1234)"
              value={activationCode}
              onChange={e => setActivationCode(e.target.value)}
            />
            <button 
              onClick={handleActivate}
              className="bg-[#002C5F] text-white px-6 rounded-xl font-bold hover:bg-opacity-90 transition-all shadow-lg text-sm"
            >
              GO
            </button>
          </div>
          {error && <p className="text-red-500 text-[10px] mt-2 font-bold">{error}</p>}
        </div>

        <div className="space-y-4">
          <button 
            onClick={() => onNavigate(Page.TICKET)}
            className="w-full py-4 bg-white border-2 border-[#002C5F] text-[#002C5F] font-bold rounded-2xl hover:bg-gray-50 transition-all flex items-center justify-center space-x-2"
          >
            <i className="fas fa-ticket-alt"></i>
            <span>Download Digital Ticket</span>
          </button>
          <button 
            onClick={() => onNavigate(Page.LANDING)}
            className="w-full py-2 text-gray-400 text-xs font-bold uppercase tracking-widest hover:text-gray-600 transition-colors"
          >
            Return to Homepage
          </button>
        </div>
      </div>
    </div>
  );
};

export default PaymentSuccessPage;
