
import React, { useState } from 'react';
import { Page, Attendee } from '../types';
import { EVENT_DETAILS } from '../constants';

interface TicketPageProps {
  user: Attendee | null;
  onNavigate: (page: Page) => void;
}

const TicketPage: React.FC<TicketPageProps> = ({ user, onNavigate }) => {
  const [activationCode, setActivationCode] = useState('');
  const [error, setError] = useState(false);

  if (!user) return <div className="p-20 text-center">No ticket found. Please register first.</div>;

  const handleDownload = () => {
    alert('Generating your high-resolution ticket... Your PDF download will begin shortly.');
  };

  const handleGoToProfile = () => {
    if (activationCode.toUpperCase() === user.id.toUpperCase()) {
      onNavigate(Page.USER_PROFILE);
    } else {
      setError(true);
      setTimeout(() => setError(false), 3000);
    }
  };

  return (
    <div className="py-16 bg-[#F3F4F6] min-h-screen">
      <div className="max-w-3xl mx-auto px-4">
        <div className="mb-8 flex justify-between items-end">
          <div>
            <h2 className="text-3xl font-bold text-[#002C5F]">Digital Ticket</h2>
            <p className="text-gray-500">Keep this ready for entry at the venue</p>
          </div>
          <button 
            onClick={handleDownload}
            className="bg-[#002C5F] text-white px-6 py-3 rounded-xl font-bold hover:scale-105 transition-all flex items-center shadow-lg"
          >
            <i className="fas fa-download mr-2"></i>
            Download PDF
          </button>
        </div>

        {/* Ticket Container */}
        <div className="relative overflow-hidden bg-white rounded-[2rem] shadow-2xl flex flex-col md:flex-row border border-gray-100 mb-10">
          <div className="p-10 md:w-2/3 border-b md:border-b-0 md:border-r border-dashed border-gray-300">
            <div className="flex items-center space-x-4 mb-8">
               <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/4/44/Hyundai_Motor_Company_logo.svg/1024px-Hyundai_Motor_Company_logo.svg.png" className="h-4" alt="Hyundai" />
               <div className="h-4 w-px bg-gray-300"></div>
               <span className="text-xs font-black tracking-widest text-[#002C5F]">OFFICIAL PASS</span>
            </div>

            <div className="space-y-6">
              <div>
                <p className="text-xs text-gray-400 font-bold uppercase tracking-widest mb-1">Pass Holder</p>
                <h3 className="text-2xl font-bold text-gray-900">{user.name}</h3>
              </div>
              
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <p className="text-xs text-gray-400 font-bold uppercase tracking-widest mb-1">Vehicle</p>
                  <p className="font-bold text-gray-700">{user.vehicleModel}</p>
                  <p className="text-sm text-gray-500 uppercase">{user.vehicleRegNo}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-400 font-bold uppercase tracking-widest mb-1">Team Assignment</p>
                  <p className={`font-bold ${user.team === 'Red' ? 'text-red-600' : 'text-[#00AAD2]'}`}>Team {user.team}</p>
                </div>
              </div>

              <div className="pt-6 border-t border-gray-100">
                <div className="flex items-center space-x-8">
                  <div>
                    <p className="text-xs text-gray-400 font-bold uppercase tracking-widest mb-1">Event Date</p>
                    <p className="font-bold text-[#002C5F]">Feb 28, 2026</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-400 font-bold uppercase tracking-widest mb-1">Check-in</p>
                    <p className="font-bold text-[#002C5F]">{EVENT_DETAILS.registrationTime}</p>
                  </div>
                </div>
              </div>
              
              <div className="bg-gray-50 p-4 rounded-xl text-[10px] text-gray-500 leading-relaxed border border-gray-100">
                <i className="fas fa-info-circle mr-2 text-[#00AAD2]"></i>
                Present this QR code at the registration desk to receive your colour-coded RFID wristband and event kit.
              </div>
            </div>
          </div>

          <div className="md:w-1/3 bg-gray-50 p-10 flex flex-col items-center justify-center text-center">
             <div className="bg-white p-4 rounded-2xl shadow-sm mb-6 border border-gray-200">
                <div className="w-32 h-32 bg-gray-100 flex items-center justify-center border-2 border-dashed border-gray-200">
                   <i className="fas fa-qrcode text-6xl text-gray-300"></i>
                </div>
             </div>
             <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mb-1">REGISTRATION ID</p>
             <p className="text-xl font-black text-[#002C5F] tracking-widest mb-2">{user.id}</p>
             <p className="text-[9px] text-gray-400 italic mb-6">Manual entry fallback code if QR fails</p>
          </div>

          <div className="hidden md:block absolute top-1/2 -translate-y-1/2 left-[66.66%] w-8 h-8 bg-[#F3F4F6] rounded-full -ml-4 border-r border-gray-200"></div>
          <div className="hidden md:block absolute top-1/2 -translate-y-1/2 right-[33.33%] w-8 h-8 bg-[#F3F4F6] rounded-full -mr-4 border-l border-gray-200"></div>
        </div>

        {/* Command Center Quick Link Section */}
        <div className="bg-white rounded-[2rem] p-8 shadow-xl border-2 border-[#002C5F]/5">
          <div className="flex flex-col md:flex-row items-center gap-6">
            <div className="w-16 h-16 bg-blue-50 text-[#00AAD2] rounded-2xl flex items-center justify-center text-3xl shadow-inner shrink-0">
              <i className="fas fa-mobile-alt"></i>
            </div>
            <div className="flex-grow text-center md:text-left">
              <h3 className="text-lg font-black text-[#002C5F] uppercase tracking-tight">ALREADY REGISTERED?</h3>
              <p className="text-sm text-gray-500 leading-relaxed">Enter your Registration ID above to access your Live Digital Profile and start participating in the drive and carnival activities.</p>
            </div>
            <div className="w-full md:w-auto flex flex-col gap-2">
               <div className="relative">
                 <input 
                   type="text"
                   value={activationCode}
                   onChange={e => setActivationCode(e.target.value)}
                   placeholder="Enter code"
                   className={`w-full md:w-40 px-4 py-3 rounded-xl border-2 bg-gray-50 text-sm font-bold uppercase outline-none transition-all ${error ? 'border-red-500 animate-shake' : 'border-gray-200 focus:border-[#00AAD2]'}`}
                 />
               </div>
               <button 
                onClick={handleGoToProfile}
                className="w-full md:w-auto px-6 py-3 bg-[#002C5F] text-white font-bold rounded-xl text-xs hover:bg-opacity-90 transition-all shadow-md"
               >
                 GO TO COMMAND CENTER
               </button>
            </div>
          </div>
          {error && <p className="text-red-500 text-[10px] font-bold text-center md:text-right mt-2 uppercase">Please enter your correct Registration ID: {user.id}</p>}
        </div>

        <div className="mt-12 text-center text-gray-400 text-sm">
           <p className="flex items-center justify-center space-x-2">
             <span>Questions? Contact our support at</span>
             <a href="tel:18001022026" className="text-[#002C5F] font-bold hover:text-[#00AAD2] transition-colors flex items-center">
               <i className="fas fa-phone-alt mr-2 text-xs"></i>
               1800 102 2026
             </a>
           </p>
        </div>
      </div>
    </div>
  );
};

export default TicketPage;
