
import React, { useState, useEffect } from 'react';
import { Page, Attendee, RegistrationStatus } from '../types';
import { api } from '../api';

interface AdminDashboardPageProps {
  attendees: Attendee[];
  setAttendees: React.Dispatch<React.SetStateAction<Attendee[]>>;
  onNavigate: (page: Page) => void;
}

const AdminDashboardPage: React.FC<AdminDashboardPageProps> = ({ attendees, setAttendees, onNavigate }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filter, setFilter] = useState<RegistrationStatus | 'ALL' | 'CHECKED_IN' | 'COMPLETED'>('ALL');
  const [selectedGuest, setSelectedGuest] = useState<Attendee | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      const data = await api.getAttendees();
      setAttendees(data);
    };
    fetchData();
  }, [setAttendees]);

  const handleCheckIn = async (id: string) => {
    const success = await api.checkIn(id);
    if (success) {
      setAttendees(prev => prev.map(a => a.id === id ? { ...a, isCheckedIn: true } : a));
    }
  };

  const filteredAttendees = attendees.filter(a => {
    const matchesSearch = a.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          a.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          a.vehicleRegNo.toLowerCase().includes(searchTerm.toLowerCase());
    
    if (filter === 'CHECKED_IN') return matchesSearch && a.isCheckedIn;
    if (filter === 'COMPLETED') return matchesSearch && a.journeyStep >= 6;
    const matchesFilter = filter === 'ALL' || a.paymentStatus === filter;
    return matchesSearch && matchesFilter;
  });

  const stats = {
    total: attendees.length,
    checkedIn: attendees.filter(a => a.isCheckedIn).length,
    completed: attendees.filter(a => a.journeyStep >= 6).length,
    totalPoints: attendees.reduce((acc, curr) => acc + (curr.points || 0), 0)
  };

  return (
    <div className="py-8 bg-gray-50 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center mb-10">
          <div>
            <h2 className="text-3xl font-bold text-[#002C5F]">Event Command Center</h2>
            <p className="text-gray-500 font-medium">Monitoring {stats.total} total guests at the Lucknow Carnival</p>
          </div>
          <button onClick={() => alert("Terminal initialized. Waiting for RFID scan...")} className="bg-[#002C5F] text-white px-6 py-3 rounded-xl font-bold shadow-lg flex items-center"><i className="fas fa-qrcode mr-2"></i> Scan Guest</button>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-10">
          <StatCard label="Total Guests" value={stats.total} color="text-gray-900" />
          <StatCard label="Live Check-ins" value={stats.checkedIn} color="text-green-600" />
          <StatCard label="Drive Finishers" value={stats.completed} color="text-blue-600" />
          <StatCard label="Points Allocated" value={stats.totalPoints} color="text-yellow-600" />
        </div>

        {/* Filters */}
        <div className="bg-white p-6 rounded-t-3xl border-x border-t border-gray-100 flex flex-col md:flex-row gap-6 justify-between items-center shadow-sm">
           <div className="relative w-full max-w-lg">
             <i className="fas fa-search absolute left-4 top-1/2 -translate-y-1/2 text-gray-400"></i>
             <input type="text" placeholder="Search by name, ID, or Vehicle Plate..." className="w-full pl-12 pr-4 py-3 bg-gray-50 border-0 rounded-2xl outline-none focus:ring-2 focus:ring-[#00AAD2] font-medium" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
           </div>
           <div className="flex gap-2">
             {['ALL', 'CHECKED_IN', 'COMPLETED'].map(f => (
               <button key={f} onClick={() => setFilter(f as any)} className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${filter === f ? 'bg-[#002C5F] text-white shadow-lg' : 'bg-gray-100 text-gray-400 hover:bg-gray-200'}`}>{f.replace('_', ' ')}</button>
             ))}
           </div>
        </div>

        {/* Table */}
        <div className="bg-white border border-gray-100 rounded-b-3xl overflow-hidden shadow-2xl">
           <div className="overflow-x-auto">
             <table className="w-full text-left">
               <thead>
                 <tr className="bg-gray-50/50 border-b border-gray-100">
                   <th className="px-6 py-5 text-[10px] font-black text-gray-400 uppercase tracking-widest">Guest & Vehicle</th>
                   <th className="px-6 py-5 text-[10px] font-black text-gray-400 uppercase tracking-widest">Team/Points</th>
                   <th className="px-6 py-5 text-[10px] font-black text-gray-400 uppercase tracking-widest">Activity Score</th>
                   <th className="px-6 py-5 text-[10px] font-black text-gray-400 uppercase tracking-widest">Feedback Status</th>
                   <th className="px-6 py-5 text-[10px] font-black text-gray-400 uppercase tracking-widest text-right">Actions</th>
                 </tr>
               </thead>
               <tbody className="divide-y divide-gray-100">
                 {filteredAttendees.map(attendee => (
                   <tr key={attendee.id} className={`hover:bg-blue-50/20 transition-all ${attendee.isCheckedIn ? 'bg-green-50/10' : ''}`}>
                     <td className="px-6 py-6">
                       <div className="font-bold text-gray-900">{attendee.name}</div>
                       <div className="text-[10px] text-gray-400 font-bold uppercase mt-1">{attendee.vehicleModel} • {attendee.vehicleRegNo}</div>
                     </td>
                     <td className="px-6 py-6">
                       <span className={`inline-block px-2 py-1 rounded-md text-[10px] font-black text-white mr-3 ${attendee.team === 'Red' ? 'bg-red-500' : 'bg-green-500'}`}>TEAM {attendee.team}</span>
                       <span className="font-black text-[#002C5F] text-lg">{attendee.points}</span>
                     </td>
                     <td className="px-6 py-6">
                        <div className="w-32 bg-gray-100 h-1.5 rounded-full overflow-hidden mb-1"><div className="bg-[#00AAD2] h-full" style={{ width: `${(attendee.journeyStep / 6) * 100}%` }}></div></div>
                        <span className="text-[10px] font-bold text-gray-400 uppercase tracking-tighter">{attendee.journeyStep}/6 Drive Riddle Completed</span>
                     </td>
                     <td className="px-6 py-6">
                        {attendee.feedback ? (
                           <div className="flex items-center text-red-600"><i className="fas fa-star text-[10px] mr-1"></i><span className="text-xs font-black">{attendee.feedback.rating}/5 Rating</span></div>
                        ) : (<span className="text-[10px] text-gray-300 font-bold uppercase italic">Awaiting Feedback</span>)}
                     </td>
                     <td className="px-6 py-6 text-right space-x-2">
                        {!attendee.isCheckedIn && <button onClick={() => handleCheckIn(attendee.id)} className="px-3 py-1.5 bg-green-500 text-white text-[9px] font-black rounded-lg shadow-md uppercase">Check In</button>}
                        <button onClick={() => setSelectedGuest(attendee)} className="px-3 py-1.5 bg-[#002C5F] text-white text-[9px] font-black rounded-lg shadow-md uppercase">View All Info</button>
                     </td>
                   </tr>
                 ))}
               </tbody>
             </table>
           </div>
        </div>
      </div>

      {/* Guest Details Modal */}
      {selectedGuest && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-black/40 backdrop-blur-sm animate-fadeIn">
           <div className="bg-white w-full max-w-2xl rounded-[3rem] shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
              <div className="p-8 bg-[#002C5F] text-white flex justify-between items-center">
                 <div>
                    <h3 className="text-2xl font-black">{selectedGuest.name}</h3>
                    <p className="text-blue-200 text-xs font-bold uppercase tracking-[0.2em]">{selectedGuest.id} • Registered Profile</p>
                 </div>
                 <button onClick={() => setSelectedGuest(null)} className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-all"><i className="fas fa-times"></i></button>
              </div>
              <div className="p-8 overflow-y-auto space-y-8 flex-grow">
                 <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
                    <InfoBox label="Phone" value={selectedGuest.phone} />
                    <InfoBox label="Email" value={selectedGuest.email} />
                    <InfoBox label="Vehicle" value={selectedGuest.vehicleModel} sub={selectedGuest.vehicleRegNo} />
                    <InfoBox label="Team" value={`Team ${selectedGuest.team}`} />
                    <InfoBox label="Current Points" value={`${selectedGuest.points} Pts`} />
                    <InfoBox label="Check-in Status" value={selectedGuest.isCheckedIn ? "Checked In" : "Not Present"} color={selectedGuest.isCheckedIn ? "text-green-600" : "text-red-500"} />
                 </div>

                 <div className="space-y-4">
                    <h4 className="text-xs font-black text-gray-400 uppercase tracking-widest border-b pb-2">Carnival Zone Participation</h4>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                       {selectedGuest.carnivalProgress.map(zone => (
                          <div key={zone.zoneId} className="p-4 rounded-2xl bg-gray-50 border border-gray-100">
                             <p className="text-[10px] font-black text-gray-900 truncate mb-1">{zone.zoneId}: {zone.status}</p>
                             <p className="text-[10px] font-bold text-[#00AAD2]">{zone.points} Points Earned</p>
                          </div>
                       ))}
                    </div>
                 </div>

                 {selectedGuest.feedback && (
                    <div className="space-y-4">
                       <h4 className="text-xs font-black text-gray-400 uppercase tracking-widest border-b pb-2">Riddle Rush Feedback</h4>
                       <div className="bg-blue-50 p-6 rounded-[2rem] space-y-3">
                          <div className="flex justify-between">
                             <span className="text-xs font-bold text-blue-900">Rating: {selectedGuest.feedback.rating}/5</span>
                             <span className="text-xs font-bold text-[#00AAD2]">{selectedGuest.feedback.socialHandle}</span>
                          </div>
                          <p className="text-xs text-blue-800 italic leading-relaxed">"{selectedGuest.feedback.comment}"</p>
                          <div className="flex flex-wrap gap-2">
                             {selectedGuest.feedback.tags.map(t => <span key={t} className="px-2 py-1 bg-white text-[9px] font-bold text-blue-600 rounded-lg">{t}</span>)}
                          </div>
                       </div>
                    </div>
                 )}

                 {selectedGuest.overallEventFeedback && (
                    <div className="space-y-4">
                       <h4 className="text-xs font-black text-gray-400 uppercase tracking-widest border-b pb-2">Post-Event Overall Feedback</h4>
                       <div className="bg-green-50 p-6 rounded-[2rem]">
                          <p className="text-xs text-green-900 leading-relaxed italic">"{selectedGuest.overallEventFeedback}"</p>
                       </div>
                    </div>
                 )}
              </div>
           </div>
        </div>
      )}
    </div>
  );
};

const StatCard = ({ label, value, color }: { label: string, value: number, color: string }) => (
  <div className="bg-white p-6 rounded-[2.5rem] shadow-sm border border-gray-100">
    <p className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-2">{label}</p>
    <p className={`text-4xl font-black ${color}`}>{value}</p>
  </div>
);

const InfoBox = ({ label, value, sub, color }: { label: string, value: string, sub?: string, color?: string }) => (
  <div>
    <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest mb-1">{label}</p>
    <p className={`text-sm font-bold ${color || 'text-gray-900'}`}>{value}</p>
    {sub && <p className="text-[10px] text-gray-400 font-bold uppercase">{sub}</p>}
  </div>
);

export default AdminDashboardPage;
