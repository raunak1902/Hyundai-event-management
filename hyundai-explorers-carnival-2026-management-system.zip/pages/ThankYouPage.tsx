
import React, { useState } from 'react';
import { Page, Attendee } from '../types';
import { api } from '../api';

interface ThankYouPageProps {
  user: Attendee | null;
  onNavigate: (page: Page) => void;
}

const ThankYouPage: React.FC<ThankYouPageProps> = ({ user, onNavigate }) => {
  const [submitted, setSubmitted] = useState(false);
  const [comment, setComment] = useState('');
  const [loading, setLoading] = useState(false);

  if (!user) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    await api.updateOverallFeedback(user.id, comment);
    setSubmitted(true);
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-[#F0F2F5] pb-10 flex flex-col items-center">
      <div className="w-full max-w-[450px] bg-white shadow-2xl min-h-screen flex flex-col font-sans relative">
        <div className="p-8 text-center pt-20">
           {!submitted ? (
             <div className="animate-fadeIn">
               <div className="w-20 h-20 bg-green-50 text-green-500 rounded-full flex items-center justify-center mx-auto mb-8 text-3xl"><i className="fas fa-heart"></i></div>
               <h2 className="text-3xl font-black text-[#002C5F] mb-4">Thank You!</h2>
               <p className="text-gray-500 text-sm leading-relaxed mb-10">We appreciate your presence at the Hyundai Explorers Carnival 2026. You made it special!</p>
               <div className="bg-gray-50 p-8 rounded-[2.5rem] border border-gray-100 mb-10">
                  <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Final Event Score</p>
                  <p className="text-5xl font-black text-[#002C5F]">{user.points}</p>
               </div>
               <div className="text-left bg-white p-6 rounded-3xl border-2 border-dashed border-[#002C5F]/10 mb-8">
                  <h4 className="text-xs font-black text-[#002C5F] uppercase mb-4 tracking-tight">Your Feedback Matters</h4>
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <textarea 
                      required
                      className="w-full bg-gray-50 border border-gray-100 rounded-2xl p-4 text-xs h-32 outline-none focus:ring-2 focus:ring-[#00AAD2] resize-none"
                      placeholder="Share your overall experience of the event..."
                      value={comment}
                      onChange={(e) => setComment(e.target.value)}
                    ></textarea>
                    <button 
                      type="submit" 
                      disabled={loading}
                      className="w-full py-4 bg-[#002C5F] text-white font-black rounded-2xl shadow-lg shadow-blue-900/20 active:scale-95 transition-all uppercase tracking-widest text-xs"
                    >
                       {loading ? 'Submitting...' : 'Submit Experience'}
                    </button>
                  </form>
               </div>
             </div>
           ) : (
             <div className="py-20 animate-scaleIn">
                <div className="w-24 h-24 bg-blue-50 text-[#00AAD2] rounded-full flex items-center justify-center mx-auto mb-10 text-4xl"><i className="fas fa-envelope-circle-check"></i></div>
                <h3 className="text-2xl font-black text-[#002C5F] mb-4">Feedback Received!</h3>
                <p className="text-gray-400 text-sm mb-12">We've sent a summary and participation certificate to <span className="text-[#00AAD2] font-bold">{user.email}</span>.</p>
                <button onClick={() => onNavigate(Page.LANDING)} className="w-full py-5 border-2 border-[#002C5F] text-[#002C5F] font-black rounded-2xl uppercase tracking-widest text-xs">Return to Home</button>
             </div>
           )}
        </div>
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-6 bg-black rounded-b-2xl"></div>
      </div>
    </div>
  );
};

export default ThankYouPage;
