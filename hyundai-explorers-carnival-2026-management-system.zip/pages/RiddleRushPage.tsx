
import React, { useState, useEffect } from 'react';
import { Page, Attendee, Feedback } from '../types';
import { api } from '../api';

interface RiddleRushPageProps {
  user: Attendee | null;
  onNavigate: (page: Page) => void;
  onUpdate: () => void;
}

const RiddleRushPage: React.FC<RiddleRushPageProps> = ({ user, onNavigate, onUpdate }) => {
  const [currentStep, setCurrentStep] = useState(user?.journeyStep || 0);
  const [loading, setLoading] = useState(false);
  const [foundWords, setFoundWords] = useState<string[]>([]);
  const [rating, setRating] = useState(4);
  const [selectedTags, setSelectedTags] = useState<string[]>(['Overall Service', 'Repair Quality']);
  const [comment, setComment] = useState('');
  const [socialHandle, setSocialHandle] = useState('');

  const words = ['CRETA', 'VERNA', 'LUCKNOW', 'COMMUNITY'];
  const tags = ['Overall Service', 'Customer Support', 'Speed and Efficiency', 'Repair Quality', 'Pickup and Delivery Service', 'Transparency'];

  const handleNextStep = async (pointsToAdd: number = 0, fb?: Feedback) => {
    if (!user) return;
    setLoading(true);
    const nextStep = currentStep + 1;
    await api.updateJourney(user.id, nextStep, pointsToAdd, fb);
    onUpdate();
    setCurrentStep(nextStep);
    setLoading(false);
  };

  if (!user) return null;

  const renderContent = () => {
    if (loading) return (
      <div className="flex-grow flex items-center justify-center">
        <div className="w-10 h-10 border-4 border-[#002C5F] border-t-transparent rounded-full animate-spin"></div>
      </div>
    );

    switch (currentStep) {
      case 0: return (
        <div className="flex flex-col h-full bg-white rounded-[2.5rem] p-8 shadow-xl">
          <div className="mb-8">
            <h2 className="text-2xl font-black text-[#002C5F] mb-4 uppercase">Drive Activation</h2>
            <p className="text-sm text-gray-500 leading-relaxed mb-6">Ready for the Riddle Rush? Review these rules to maximize your score.</p>
            <div className="space-y-4">
              <div className="bg-orange-50 border-l-4 border-orange-400 p-4 rounded-r-xl">
                <h4 className="font-bold text-orange-900 text-sm mb-1 uppercase tracking-tight">Mega Prize Opportunity</h4>
                <p className="text-xs text-orange-700 leading-normal font-medium">The best-performing explorer wins a <strong>Car DashCam!</strong></p>
              </div>
              <div className="bg-blue-50 border-l-4 border-blue-400 p-4 rounded-r-xl">
                <h4 className="font-bold text-blue-900 text-sm mb-1 uppercase tracking-tight">Safety Protocol</h4>
                <p className="text-xs text-blue-700 leading-normal">• Seatbelts mandatory.<br/>• Points are for riddles, NOT speed.</p>
              </div>
            </div>
          </div>
          <button onClick={() => handleNextStep(0)} className="mt-auto w-full py-5 bg-[#002C5F] text-white font-bold rounded-2xl shadow-xl">I ACCEPT & START DRIVE</button>
        </div>
      );
      case 1: return (
        <div className="flex flex-col h-full bg-[#EBF3F9] rounded-[2.5rem] p-8 shadow-xl">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-black text-[#002C5F]">QUIZ 1: Crossword</h2>
            <div className="bg-white/80 px-4 py-1.5 rounded-full text-xs font-black text-blue-600">PTS: {foundWords.length * 2.5}</div>
          </div>
          <div className="bg-white p-4 rounded-2xl grid grid-cols-8 gap-1 mb-8 shadow-inner">
            {"HYUNDAICRETAVERNAEXPLORERSLUCKNOWCITYROADTEAM".split('').map((char, i) => (
              <div key={i} className="aspect-square flex items-center justify-center font-black text-[#002C5F] bg-gray-50 rounded-md text-xs border border-gray-100 uppercase">{char}</div>
            ))}
          </div>
          <div className="space-y-2">
            {words.map(w => (
              <button key={w} onClick={() => { if(!foundWords.includes(w)) { const nf = [...foundWords, w]; setFoundWords(nf); if(nf.length === words.length) setTimeout(() => handleNextStep(10), 800); }}} className={`w-full p-4 rounded-xl border-2 transition-all font-bold text-sm ${foundWords.includes(w) ? 'bg-green-50 border-green-500 text-green-700 shadow-inner' : 'bg-white border-transparent text-gray-400'}`}>{w} {foundWords.includes(w) && <i className="fas fa-check ml-2"></i>}</button>
            ))}
          </div>
        </div>
      );
      case 2: case 4: return (
        <div className="flex flex-col h-full bg-white rounded-[2.5rem] p-8 shadow-xl text-center">
          <div className="w-20 h-20 bg-green-50 text-green-500 rounded-full flex items-center justify-center mx-auto mb-6 text-3xl"><i className="fas fa-map-marker-alt"></i></div>
          <h2 className="text-2xl font-black text-[#002C5F] mb-2 uppercase">Pit Stop Arrival</h2>
          <p className="text-sm text-gray-400 mb-10">Scan your wristband QR code to claim points.</p>
          <div className="bg-gray-50 p-10 rounded-3xl mb-10 border border-gray-100 flex flex-col items-center"><i className="fas fa-qrcode text-gray-200 text-7xl"></i></div>
          <button onClick={() => handleNextStep(5)} className="w-full py-5 bg-[#00AAD2] text-white font-bold rounded-2xl shadow-lg">I'VE SCANNED - CONTINUE</button>
        </div>
      );
      case 3: return (
        <div className="flex flex-col h-full bg-white rounded-[2.5rem] p-8 shadow-xl">
          <h2 className="text-xl font-black text-[#002C5F] mb-6 uppercase">Quiz 2: Jigsaw</h2>
          <div className="relative aspect-square bg-gray-100 rounded-2xl overflow-hidden grid grid-cols-3 gap-0.5 mb-8 border border-gray-200">
             {[...Array(9)].map((_, i) => (<div key={i} className="bg-white flex items-center justify-center text-blue-50"><i className="fas fa-puzzle-piece text-4xl opacity-20"></i></div>))}
             <div className="absolute inset-0 flex items-center justify-center"><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/4/44/Hyundai_Motor_Company_logo.svg/1024px-Hyundai_Motor_Company_logo.svg.png" className="w-1/2 opacity-30 animate-pulse" alt="H" /></div>
          </div>
          <button onClick={() => handleNextStep(10)} className="w-full py-5 bg-[#002C5F] text-white font-bold rounded-2xl shadow-xl">SOLVE JIGSAW (10 PTS)</button>
        </div>
      );
      case 5: return (
        <div className="flex flex-col h-full bg-white rounded-[2.5rem] p-8 shadow-xl overflow-y-auto no-scrollbar">
          <h2 className="text-2xl font-black text-[#002C5F] mb-2 uppercase tracking-tight">Final Verdict</h2>
          <div className="flex justify-center space-x-3 mb-10">
            {[1,2,3,4,5].map(star => (<i key={star} onClick={() => setRating(star)} className={`fas fa-star text-3xl cursor-pointer transition-all ${star <= rating ? 'text-red-600 scale-110' : 'text-gray-200 hover:text-gray-300'}`}></i>))}
          </div>
          <div className="space-y-6 mb-8">
            <div>
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest block mb-3">Improvement Areas</label>
              <div className="flex flex-wrap gap-2">
                {tags.map(tag => (<button key={tag} onClick={() => setSelectedTags(prev => prev.includes(tag) ? prev.filter(t => t !== tag) : [...prev, tag])} className={`px-3 py-2 rounded-xl text-[10px] font-bold transition-all border ${selectedTags.includes(tag) ? 'bg-[#00AAD2] text-white border-[#00AAD2]' : 'bg-gray-50 text-gray-400 border-gray-100'}`}>{tag}</button>))}
              </div>
            </div>
            <textarea className="w-full p-5 bg-gray-50 rounded-2xl border border-gray-100 text-sm h-28 outline-none focus:border-[#00AAD2] focus:bg-white transition-all resize-none" placeholder="Share your experience..." value={comment} onChange={e => setComment(e.target.value)} />
            <div>
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest block mb-2 px-1">Social Media Handle</label>
              <input className="w-full px-5 py-4 bg-gray-50 rounded-2xl border border-gray-100 text-sm outline-none focus:border-[#00AAD2] focus:bg-white" placeholder="@your_handle" value={socialHandle} onChange={e => setSocialHandle(e.target.value)} />
            </div>
          </div>
          <button onClick={() => handleNextStep(15, { rating, tags: selectedTags, comment, socialHandle })} className="w-full py-5 bg-[#002C5F] text-white font-bold rounded-2xl shadow-xl mt-auto">SUBMIT & FINISH (+15 PTS)</button>
        </div>
      );
      case 6: return (
        <div className="flex flex-col h-full bg-white rounded-[2.5rem] p-10 shadow-xl text-center">
          <div className="w-24 h-24 bg-yellow-50 text-yellow-500 rounded-full flex items-center justify-center mx-auto mb-8 text-4xl shadow-inner"><i className="fas fa-flag-checkered"></i></div>
          <h2 className="text-2xl font-black text-[#002C5F] mb-4 uppercase">Victory!</h2>
          <div className="bg-gradient-to-br from-[#002C5F] to-[#00AAD2] p-10 rounded-[2.5rem] shadow-xl mb-10 transform -rotate-1">
             <p className="text-[10px] font-black text-white/60 uppercase tracking-[0.3em] mb-2">Total Score</p>
             <p className="text-6xl font-black text-white tracking-tighter">{user.points}</p>
          </div>
          <button onClick={() => onNavigate(Page.USER_PROFILE)} className="w-full py-5 bg-[#002C5F] text-white font-bold rounded-2xl shadow-xl">GO TO COMMAND CENTER</button>
        </div>
      );
      default: return null;
    }
  };

  return (
    <div className="min-h-screen bg-[#F0F2F5] pb-10 flex flex-col items-center">
      <div className="w-full max-w-[450px] bg-white/5 min-h-screen flex flex-col font-sans p-6">
        <div className="flex items-center justify-between mb-8 px-2">
           <button onClick={() => onNavigate(Page.USER_PROFILE)} className="w-10 h-10 bg-white rounded-2xl flex items-center justify-center text-[#002C5F] shadow-sm"><i className="fas fa-chevron-left text-xs"></i></button>
           <div className="text-right">
              <div className="flex space-x-1">
                 {[0,1,2,3,4,5].map(i => (<div key={i} className={`h-1.5 w-6 rounded-full transition-all duration-500 ${i <= currentStep ? 'bg-[#00AAD2] shadow-[0_0_10px_rgba(0,170,210,0.5)]' : 'bg-gray-200'}`}></div>))}
              </div>
           </div>
        </div>
        <div className="flex-grow flex flex-col">{renderContent()}</div>
      </div>
    </div>
  );
};

export default RiddleRushPage;
