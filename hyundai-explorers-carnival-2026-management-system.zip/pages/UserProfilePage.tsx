
import React, { useState } from 'react';
import { Page, Attendee } from '../types';

interface UserProfilePageProps {
  user: Attendee | null;
  attendees: Attendee[];
  onNavigate: (page: Page) => void;
}

const UserProfilePage: React.FC<UserProfilePageProps> = ({ user, attendees, onNavigate }) => {
  const [showLeaderboard, setShowLeaderboard] = useState(false);

  if (!user) return (
    <div className="p-20 text-center bg-gray-50 min-h-screen flex flex-col items-center justify-center">
      <div className="bg-white p-10 rounded-3xl shadow-xl max-w-xs">
        <i className="fas fa-lock text-4xl text-gray-300 mb-4"></i>
        <h3 className="text-xl font-bold mb-2">Access Denied</h3>
        <p className="text-gray-500 text-sm mb-6">Please register or enter your unique code to view your profile.</p>
        <button onClick={() => onNavigate(Page.LANDING)} className="text-[#002C5F] font-bold">Back to Home</button>
      </div>
    </div>
  );

  const completedZones = user.carnivalProgress?.filter(z => z.status === 'COMPLETED').length || 0;
  const totalZones = user.carnivalProgress?.length || 5;

  // Leaderboard Logic
  const leaderboard = [...attendees].sort((a, b) => (b.points || 0) - (a.points || 0)).slice(0, 10);
  const userRank = [...attendees].sort((a, b) => (b.points || 0) - (a.points || 0)).findIndex(a => a.id === user.id) + 1;

  return (
    <div className="min-h-screen bg-[#F0F2F5] pb-10 flex flex-col items-center">
      <div className="w-full max-w-[450px] bg-white shadow-2xl min-h-screen flex flex-col font-sans relative overflow-hidden">
        {/* Header Image */}
        <div className="relative w-full h-[250px]">
          <img 
            src="https://images.unsplash.com/photo-1619767886558-efdc259cde1a?auto=format&fit=crop&q=80&w=800" 
            className="w-full h-full object-cover"
            alt="Hyundai Carnival"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
          <div className="absolute top-8 left-0 w-full text-center">
            <h1 className="text-white font-black text-2xl tracking-tight uppercase">#HyundaiExplorers</h1>
            <p className="text-white/80 text-[10px] font-bold uppercase tracking-[0.3em]">Lucknow Carnival 2026</p>
          </div>
          
          <div className="absolute bottom-6 left-6 right-6 flex justify-between items-end">
             <div className="text-white">
                <p className="text-[10px] font-bold uppercase opacity-80 tracking-widest">Explorer Profile</p>
                <p className="text-2xl font-black">{user.name.split(' ')[0]}</p>
                <p className="text-[10px] font-medium text-white/60">{user.id}</p>
             </div>
             <div className="bg-white/95 backdrop-blur-sm px-4 py-2 rounded-2xl flex items-center space-x-2 shadow-xl border border-white/50">
               <div className="w-6 h-6 bg-yellow-400 rounded-full flex items-center justify-center text-white text-[10px]">
                 <i className="fas fa-star"></i>
               </div>
               <span className="text-lg font-black text-[#002C5F]">{user.points || 0}</span>
               <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Pts</span>
            </div>
          </div>
        </div>

        {/* DashCam Banner */}
        <div className="m-6 bg-gradient-to-br from-[#002C5F] to-[#00AAD2] p-5 rounded-[2rem] shadow-lg relative group overflow-hidden">
          <div className="absolute -right-4 -bottom-4 text-white opacity-10 group-hover:scale-110 transition-transform">
            <i className="fas fa-video text-7xl"></i>
          </div>
          <div className="relative z-10 flex items-center space-x-4">
             <div className="bg-white/20 p-3 rounded-2xl">
               <i className="fas fa-trophy text-white text-xl"></i>
             </div>
             <div>
                <h4 className="text-white font-black text-lg">Mega Prize Alert!</h4>
                <p className="text-white/80 text-[10px] font-medium leading-normal">The top explorer on the tally wins a <strong>Car DashCam</strong>.<br/>Currently Ranked: <span className="text-white font-black">#{userRank}</span></p>
             </div>
          </div>
        </div>

        {/* Command Center Content */}
        <div className="px-6 flex flex-col space-y-4">
          <button 
            onClick={() => onNavigate(Page.RIDDLE_RUSH)}
            className="w-full p-6 bg-[#D3DBE8] text-[#002C5F] font-black rounded-[2rem] hover:bg-[#C5D0E0] transition-all flex items-center justify-between group"
          >
            <div className="flex items-center space-x-4 text-left">
              <div className="w-10 h-10 bg-white/50 rounded-xl flex items-center justify-center">
                <i className="fas fa-car"></i>
              </div>
              <div>
                <span className="block text-lg">Riddle Rush</span>
                <span className="block text-[10px] opacity-60 uppercase font-bold tracking-widest">Drive Experience</span>
              </div>
            </div>
            <i className="fas fa-chevron-right text-xs opacity-30 group-hover:translate-x-1 transition-transform"></i>
          </button>

          <button 
            onClick={() => onNavigate(Page.CARNIVAL_JOURNEY)}
            className="w-full p-6 bg-[#D3DBE8] text-[#002C5F] font-black rounded-[2rem] hover:bg-[#C5D0E0] transition-all flex items-center justify-between group"
          >
            <div className="flex items-center space-x-4 text-left">
              <div className="w-10 h-10 bg-white/50 rounded-xl flex items-center justify-center">
                <i className="fas fa-map-marked-alt"></i>
              </div>
              <div>
                <span className="block text-lg">Carnival Journey</span>
                <span className="block text-[10px] opacity-60 uppercase font-bold tracking-widest">{completedZones}/{totalZones} Zones Explored</span>
              </div>
            </div>
            <i className="fas fa-chevron-right text-xs opacity-30 group-hover:translate-x-1 transition-transform"></i>
          </button>

          {/* Points Progress Tally Button (Opens Leaderboard) */}
          <button 
            onClick={() => setShowLeaderboard(true)}
            className="bg-white border-2 border-[#00AAD2]/20 p-6 rounded-[2rem] flex items-center justify-between shadow-sm hover:border-[#00AAD2] transition-all text-left"
          >
             <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-blue-50 text-[#00AAD2] rounded-2xl flex items-center justify-center text-xl">
                  <i className="fas fa-chart-line"></i>
                </div>
                <div>
                   <h4 className="text-sm font-black text-[#002C5F] uppercase tracking-tight">Live Points Tally</h4>
                   <p className="text-[9px] text-gray-400 font-bold uppercase tracking-widest">See Global Rankings</p>
                </div>
             </div>
             <div className="text-right">
                <p className="text-2xl font-black text-[#00AAD2]">{user.points || 0}</p>
                <p className="text-[9px] font-black text-gray-300 uppercase">Rank #{userRank}</p>
             </div>
          </button>
        </div>

        <div className="mt-auto py-8 text-center px-10">
           <button onClick={() => onNavigate(Page.THANK_YOU)} className="text-[11px] font-bold text-gray-400 uppercase tracking-widest hover:text-[#002C5F] transition-colors">
              Finish Carnival & Feedback
           </button>
        </div>

        {/* Leaderboard Modal */}
        {showLeaderboard && (
          <div className="absolute inset-0 z-50 bg-[#002C5F]/95 backdrop-blur-md animate-fadeIn flex flex-col p-8">
            <div className="flex justify-between items-center mb-10">
               <div>
                  <h3 className="text-white text-2xl font-black uppercase tracking-tight">Live Rankings</h3>
                  <p className="text-blue-200 text-xs font-bold">Lucknow Carnival - Top 10 Explorers</p>
               </div>
               <button onClick={() => setShowLeaderboard(false)} className="w-10 h-10 bg-white/10 rounded-full text-white">
                  <i className="fas fa-times"></i>
               </button>
            </div>

            <div className="flex-grow space-y-4 overflow-y-auto no-scrollbar">
               {leaderboard.map((item, idx) => (
                 <div key={item.id} className={`flex items-center justify-between p-5 rounded-3xl border-2 transition-all ${item.id === user.id ? 'bg-white/20 border-white/40 shadow-xl scale-[1.02]' : 'bg-white/5 border-white/5'}`}>
                    <div className="flex items-center space-x-4">
                       <div className={`w-8 h-8 rounded-full flex items-center justify-center font-black text-xs ${idx === 0 ? 'bg-yellow-400 text-black' : 'text-white/60'}`}>
                          {idx + 1}
                       </div>
                       <div>
                          <p className="text-white font-bold text-sm">{item.name} {item.id === user.id && <span className="ml-2 text-[8px] bg-[#00AAD2] px-1 rounded uppercase">You</span>}</p>
                          <p className="text-white/40 text-[9px] font-bold uppercase tracking-widest">{item.vehicleModel}</p>
                       </div>
                    </div>
                    <div className="text-right">
                       <p className="text-white font-black text-lg">{item.points}</p>
                       {idx === 0 && <p className="text-yellow-400 text-[8px] font-black uppercase tracking-tighter"><i className="fas fa-award mr-1"></i>DashCam Lead</p>}
                    </div>
                 </div>
               ))}
            </div>

            <div className="mt-8 pt-6 border-t border-white/10">
               <p className="text-white/40 text-[9px] text-center italic">Leaderboard updates instantly as participants scan zones.</p>
            </div>
          </div>
        )}

        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-6 bg-black rounded-b-2xl"></div>
      </div>
    </div>
  );
};

export default UserProfilePage;
