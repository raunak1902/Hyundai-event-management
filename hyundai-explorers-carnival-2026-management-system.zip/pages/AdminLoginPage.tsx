
import React, { useState } from 'react';
import { Page } from '../types';

interface AdminLoginPageProps {
  onLogin: (success: boolean) => void;
  onNavigate: (page: Page) => void;
}

const AdminLoginPage: React.FC<AdminLoginPageProps> = ({ onLogin, onNavigate }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // Simple demo credentials
    if (email === 'admin@hyundai.com' && password === 'hyundai2026') {
      onLogin(true);
    } else {
      setError('Invalid credentials. Hint: admin@hyundai.com / hyundai2026');
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center bg-gray-50 px-4">
      <div className="max-w-md w-full bg-white rounded-3xl shadow-xl overflow-hidden">
        <div className="bg-[#002C5F] p-8 text-white text-center">
          <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/4/44/Hyundai_Motor_Company_logo.svg/1024px-Hyundai_Motor_Company_logo.svg.png" className="h-5 mx-auto mb-4 invert brightness-0" />
          <h2 className="text-2xl font-bold">Admin Portal</h2>
          <p className="text-blue-200 text-sm">Event Management System</p>
        </div>
        
        <form onSubmit={handleLogin} className="p-8 space-y-6">
          {error && (
            <div className="bg-red-50 text-red-600 p-4 rounded-xl text-sm font-medium border border-red-100">
              {error}
            </div>
          )}
          
          <div className="space-y-2">
            <label className="text-sm font-bold text-gray-700">Email Address</label>
            <input 
              type="email"
              required
              className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-white text-gray-900 outline-none focus:ring-2 focus:ring-[#002C5F]"
              value={email}
              onChange={e => setEmail(e.target.value)}
              placeholder="admin@hyundai.com"
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-bold text-gray-700">Password</label>
            <input 
              type="password"
              required
              className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-white text-gray-900 outline-none focus:ring-2 focus:ring-[#002C5F]"
              value={password}
              onChange={e => setPassword(e.target.value)}
              placeholder="••••••••"
            />
          </div>

          <button 
            type="submit"
            className="w-full py-4 bg-[#002C5F] text-white font-bold rounded-xl hover:bg-opacity-90 transition-all shadow-lg"
          >
            Sign In
          </button>
        </form>
      </div>
    </div>
  );
};

export default AdminLoginPage;
