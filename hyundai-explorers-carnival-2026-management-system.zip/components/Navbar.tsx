
import React from 'react';
import { Page } from '../types';

interface NavbarProps {
  currentPage: Page;
  onNavigate: (page: Page) => void;
  isAdmin: boolean;
  onLogout: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ currentPage, onNavigate, isAdmin, onLogout }) => {
  return (
    <nav className="bg-white border-b sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20 items-center">
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => onNavigate(Page.LANDING)}>
            <img 
              src="https://upload.wikimedia.org/wikipedia/commons/thumb/4/44/Hyundai_Motor_Company_logo.svg/1024px-Hyundai_Motor_Company_logo.svg.png" 
              alt="Hyundai Logo" 
              className="h-6 md:h-8" 
            />
            <div className="hidden sm:block border-l pl-3 border-gray-300">
              <span className="text-sm font-bold tracking-widest text-[#002C5F]">EXPLORERS CARNIVAL</span>
            </div>
          </div>

          <div className="flex items-center space-x-4">
            {isAdmin ? (
              <>
                <button 
                  onClick={() => onNavigate(Page.ADMIN_DASHBOARD)}
                  className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${currentPage === Page.ADMIN_DASHBOARD ? 'text-[#002C5F] bg-blue-50' : 'text-gray-600 hover:bg-gray-50'}`}
                >
                  Admin Dashboard
                </button>
                <button 
                  onClick={onLogout}
                  className="px-3 py-2 text-sm font-medium text-red-600 hover:bg-red-50 rounded-md transition-colors"
                >
                  Logout
                </button>
              </>
            ) : (
              <>
                <button 
                  onClick={() => onNavigate(Page.LANDING)}
                  className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${currentPage === Page.LANDING ? 'text-[#002C5F] bg-blue-50' : 'text-gray-600 hover:bg-gray-50'}`}
                >
                  Home
                </button>
                <button 
                  onClick={() => onNavigate(Page.REGISTRATION)}
                  className="bg-[#002C5F] text-white px-5 py-2 rounded-full text-sm font-semibold hover:bg-opacity-90 transition-all shadow-lg shadow-blue-900/20"
                >
                  Register Now
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
